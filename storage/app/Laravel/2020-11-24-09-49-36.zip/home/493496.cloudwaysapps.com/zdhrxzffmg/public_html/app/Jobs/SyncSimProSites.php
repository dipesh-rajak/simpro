<?php

namespace App\Jobs;

use App\Models\Customer;
use App\Models\Site;
use AppHelper;
use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use zcrmsdk\crm\crud\ZCRMRecord;
use zcrmsdk\crm\exception\ZCRMException;

class SyncSimProSites implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $sim_id, $customer;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Customer $customer, $sim_id)
    {
        $this->sim_id = $sim_id;
        $this->customer = $customer->refresh();
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        if (!$this->sim_id  || !$this->customer) {
            Log::error(__CLASS__ . ': ' . __LINE__ . "Site simpro ID && Customer is required. ");
            return;
        }
        $provider = AppHelper::getSimProProvider();
        $url = "/api/v1.0/companies/0/sites/{$this->sim_id}";
        $simSite = $provider->fetchJSON($provider->fetchRequest($url));

        //Log::debug('simSite data: '. PHP_EOL. print_r($simSite, true));

        if ($simSite) {
            $dbSite =   Site::updateOrCreate([
                'sim_id' => $simSite->ID
            ], [
                'sim_id' => $simSite->ID,
                'name' => ($simSite->Name == '') ? $this->customer->name : $simSite->Name,
                'billing_contact' => $this->customer->id,
                'address_id' => $this->customer->address->id,
                'billingAddress_id' => $this->customer->billingAddress->id,
                'public_notes' => $simSite->PublicNotes ?? '',
                'private_notes' => $simSite->PrivateNotes ?? '',
                'archived' => $simSite->Archived ?? false,
                'customer_id' => $this->customer->id

            ]);

            Log::debug('Site saved in database. SimPro ID: ' . $simSite->ID);

            $this->createZohoSite($dbSite);
        }
    }

    function createZohoSite($site)
    {


        $site = $site->load(['address', 'billing_address']);

        //Log::debug(print_r($site->toArray(), true));
        try {


            $record = ZCRMRecord::getInstance("Sites", $site->zoho_id ?? null);
            $record->setFieldValue('Name', $site->name);
            $record->setFieldValue('Street_Address', $site->address->address);
            $record->setFieldValue('Suburb',  $site->address->city);
            $record->setFieldValue('State', $site->address->state);
            $record->setFieldValue('Country', $site->address->country);

            $record->setFieldValue('Postal_Address', $site->billing_address ? $site->billing_address->address : '');
            $record->setFieldValue('Postal_State', $site->billing_address->state);
            $record->setFieldValue('Postal_Postcode', $site->billing_address->postalCode);
            $record->setFieldValue('Postal_Suburb', $site->billing_address->city);

            $record->setFieldValue('Postal_Contact', $this->customer->name);
            $record->setFieldValue('Customer_ID', (string)$this->customer->zoho_reference_id);

            $record->setFieldValue('Simpro_Site_ID', $site->sim_id);


            $trigger = array(); //triggers to include
            $lar_id = ""; //lead assignment rule id
            if (!$site->zoho_id)
                $responseIns = $record->create($trigger, $lar_id);
            else
                $responseIns = $record->update($trigger, $lar_id);

            $code = $responseIns->getHttpStatusCode(); // To get http response code
            $status =  $responseIns->getStatus(); // To get response status
            Log::debug(sprintf(" code: %s, status: %s", $code, $status));

            if ($code <= 201) {
                $zohoId =  $record->getEntityId();
                $site->zoho_id = $zohoId;
                $site->save();
                Log::debug("Site created/updated in zoho. SimPro ID: $site->sim_id, Zoho ID: $zohoId");
            } else {

                Log::error(sprintf('%s:%s error occurred while creating site %s', __CLASS__, __LINE__, $this->customer->email));
                Log::error(sprintf('%s:%s Error message %s', __CLASS__, __LINE__,   $responseIns->getMessage()));

                Log::error(sprintf('%s:%s Details %s', __CLASS__, __LINE__,    json_encode($responseIns->getDetails())));
            }
        } catch (ZCRMException $ex) {


            $code =  $ex->getExceptionCode();
            $details = $ex->getExceptionDetails();

            Log::error(sprintf('%s:%s Error Code %s', __CLASS__, __LINE__,   $code));
            Log::error(sprintf('%s:%s Error message:', __CLASS__, __LINE__,   $ex->getMessage()));
            Log::error(sprintf('%s:%s Error Details:', __CLASS__, __LINE__),   $details);

            if ($code == 'DUPLICATE_DATA') {
                if (isset($details[0]) && ($details[0]->api_name == 'Simpro_Site_ID')) {
                    $id = $details[0]->ID;
                    $site->zoho_id = $id;
                    $site->save();
                }
            }
        } catch (Exception $ex) {
            echo "error: " . $ex->getMessage() . '<br/>';
            Log::error(sprintf('%s:%s Error Occurred. %s', __CLASS__, __LINE__,   $ex->getMessage()));
            Log::error($ex->getTraceAsString());
        }
    } //create site ends
}
