<?php

namespace App\Http\Controllers;

use App\Jobs\ExportCustomersToZoho;
use App\Jobs\ExportLeadsToSimPro;
use App\Jobs\ExportCustomerToSimPro;
use App\Jobs\ExportLeadToZoho;
use App\Models\Customer;
use App\Models\Salesperson;
use App\Models\Setting;
use AppHelper;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Bus;
use Illuminate\Support\Facades\Log;
use zcrmsdk\crm\crud\ZCRMRecord;
use zcrmsdk\crm\exception\ZCRMException;
use zcrmsdk\crm\setup\restclient\ZCRMRestClient;

/**
 * Handle Zoho Webhook Requests
 */
class ZohoWebhookController extends Controller
{


    public  function index(Request $request)
    {

        Log::debug('zoho webhook received', $request->all());
        $this->validate($request, [
            'OrgID' => 'required|numeric',
            'ID' => 'required|numeric'
        ]);

        $settings = Setting::pluck('value', 'slug');

        $orgId = $request->input('OrgID');
        $leadId = $request->input('ID');

        if ($orgId !== $settings['zoho.org.id'])
            return response()->json(['error' => 'Org ID' . $orgId . ' does not exist or not configured properly'], 404);

        AppHelper::initAuth();

        //$record = ZCRMRecord::getInstance("Lead", $request->input('ID'));
        //$record = $response->getData();

        $moduleIns = ZCRMRestClient::getInstance()->getModuleInstance("Leads"); // To get module instance

        $response = $moduleIns->getRecord($leadId); // To get module records
        $record = $response->getData(); // To get response data

        try {

            $data =  $record->getData();
            Log::debug('Lead data: ' . PHP_EOL .  print_r($data, true));

            $title = $data['Salutation'] ?? '';
            if ($title != '') {
                $title = trim(str_replace('.', ' ', $title));
            }

            $leaduser = $record->getOwner();
            if ($leaduser) {
                $userName = $leaduser->getName();
                Log::debug(sprintf('Lead Id owner: %s', $userName));
                $salesperson = Salesperson::where('name', $userName)->first();
                if ($salesperson) {
                    $salesperson_id = $salesperson->id;
                    Log::debug(sprintf('Lead Id salesperson: %s id: %d', $userName, $salesperson_id));
                } else {
                    Log::debug(sprintf('Lead Id %d salesperson %s not found in staff ', $leadId, $userName));
                }
            } else {
                Log::debug(sprintf('Lead Id %d owner not found. ', $leadId));
            }


            $dbCustomer = Customer::updateOrCreate([
                'zoho_reference_id' => $leadId
            ], [
                'zoho_reference_id' => $leadId,
                'email' => $data['Email'] ?? '',
                'given_name' => $data['First_Name'] ?? '',
                'family_name' => $data['Last_Name'] ?? '',
                'title' => $title,

                'customer_type' => 'lead',
                'company_name' => $data['Company'] ?? '',
                'phone' => $data['Phone'] ?? '',
                'source' => $data['Lead_Source'] ?? '',
                'is_company' => isset($data['Type']) ? ($data['Type'] == 'Company' ? true : false) : false,
                'altphone' => $data['Other_Phone'] ?? '',
                'mobile' => $data['Mobile'] ?? '',
                'description' => $data['Description'] ?? '',
                'salesperson_id' => $salesperson_id ?? null,


            ]);

            if ($dbCustomer) {


                $dbCustomer->address()->updateOrCreate(['type' => 'address', 'customer' => $dbCustomer->id], [
                    'address' =>  $data['Street'] ?? '',
                    'city' => $data['City'] ?? '',
                    'state' => $data['State'] ?? '',
                    'postalCode' => $data['Zip_Code'] ?? '',
                    'country' => $data['Country'] ?? '',
                    'type' => 'address'
                ]);

                //save billing address
                $dbCustomer->billingAddress()->updateOrCreate(['type' => 'billing', 'customer' => $dbCustomer->id], [
                    'address' =>  $data['Street'] ?? '',
                    'city' => $data['City'] ?? '',
                    'state' => $data['State'] ?? '',
                    'postalCode' => $data['Zip_Code'] ?? '',
                    'country' => $data['Country'] ?? '',
                    'type' => 'billing'
                ]);

                //ExportLeadsToSimPro::dispatch($dbCustomer);

                /* if ($dbCustomer->wasRecentlyCreated) {
                    Log::debug(sprintf('%s:%s %s email:%s , type=%s created from zoho lead id: %d ', __CLASS__, __LINE__, $dbCustomer->customer_type, $dbCustomer->email, $dbCustomer->is_company ? 'Company' : 'Individual',  $leadId));

                    Bus::chain([
                        new  ExportLeadsToSimPro($dbCustomer),
                        new ExportCustomersToZoho($dbCustomer)
                    ])->dispatch();
                } else if ($dbCustomer->wasChanged()) {
                    Log::debug('customer info changed. changes: ', $dbCustomer->getChanges());
                    //ExportLeadsToSimPro::dispatch($dbCustomer);
                    Bus::chain([new  ExportLeadsToSimPro($dbCustomer), new ExportCustomersToZoho($dbCustomer)])->dispatch();
                } else if (!$dbCustomer->sim_lead_id) {
                    Log::debug('customer sim pro lead not found. creating new');
                    //ExportLeadsToSimPro::dispatch($dbCustomer);
                    Bus::chain([new  ExportLeadsToSimPro($dbCustomer), new ExportCustomersToZoho($dbCustomer)])->dispatch();
                } else {
                    Log::debug('No change in the customer information: ' . $dbCustomer->email);
                } */

                if($dbCustomer->wasRecentlyCreated || $dbCustomer->wasChanged()){
                    if($dbCustomer->wasChanged())
                    Log::debug(__CLASS__.__LINE__.': customer info changed. changes: ', $dbCustomer->getChanges());
                    ExportLeadsToSimPro::dispatch($dbCustomer);
                }
                else{
                    Log::debug(__CLASS__.__LINE__.': No change in the customer information: ' . $dbCustomer->email);
                }
            } //if $dbCustomer ends
            else {
                Log::error(__CLASS__.__LINE__.': No customer found or could not be created.');
            }





        } catch (ZCRMException $ex) {
            Log::debug($ex->getMessage());
        } catch (Exception $ex) {
            Log::debug($ex->getMessage());
        }
    }

    public  function customer(Request $request)
    {

        Log::debug('zoho webhook received', $request->all());
        $this->validate($request, [
            'OrgID' => 'required|numeric',
            'ID' => 'required|numeric'
        ]);

        $settings = Setting::pluck('value', 'slug');

        $orgId = $request->input('OrgID');
        $customerId = $request->input('ID');

        if ($orgId !== $settings['zoho.org.id'])
            return response()->json(['error' => 'Org ID' . $orgId . ' does not exist or not configured properly'], 404);

        AppHelper::initAuth();

        //$record = ZCRMRecord::getInstance("Lead", $request->input('ID'));
        //$record = $response->getData();

        $moduleIns = ZCRMRestClient::getInstance()->getModuleInstance("Contacts"); // To get module instance

        $response = $moduleIns->getRecord($customerId); // To get module records
        $record = $response->getData(); // To get response data

        try {

            $data =  $record->getData();
            Log::debug('Customer data: ' . PHP_EOL .  print_r($data, true));

            /* $title = $data['Salutation']??'';
            if($title !='') {
                $title = trim(str_replace('.', ' ', $title));
            }

            $leaduser = $record->getOwner();
            if($leaduser) {
                $userName = $leaduser->getName();
                Log::debug(sprintf('Lead Id owner: %s', $userName));
                $salesperson = Salesperson::where('name', $userName)->first();  
                if($salesperson)               {
                    $salesperson_id = $salesperson->id;
                    Log::debug(sprintf('Lead Id salesperson: %s id: %d', $userName, $salesperson_id));
                }
                else {
                    Log::debug(sprintf('Lead Id %d salesperson %s not found in staff ', $leadId, $userName));
                }
                
            }
            else {
                Log::debug(sprintf('Lead Id %d owner not found. ', $leadId));
            } */

            $title = $data['Salutation'] ?? '';
            if ($title != '') {
                $title = trim(str_replace('.', ' ', $title));
            }

            $dbCustomer = Customer::updateOrCreate([
                'zoho_reference_id' => $customerId
            ], [
                'zoho_reference_id' => $customerId,
                'email' => $data['Email'] ?? '',
                'given_name' => $data['First_Name'] ?? '',
                'family_name' => $data['Last_Name'] ?? '',
                'title' => $title,
                'customer_type' => 'customer',
                'company_name' => $data['Company'] ?? '',
                'phone' => $data['Phone'] ?? '',
                //'source' => $data['Lead_Source'] ?? '',
                'is_company' => isset($data['Type']) ? ($data['Type'] == 'Company' ? true : false) : false,
                'altphone' => $data['Other_Phone'] ?? '',
                'mobile' => $data['Mobile'] ?? '',
                'description' => $data['Description'] ?? '',
                'salesperson_id' => $salesperson_id ?? null,
                'source' => $data['How_Customer_Was_Acquired'] ?? ($data['Lead_Source']??null),
                'have_subscription' => $data['Have_Subscription'] ?? false,

            ]);

            if ($dbCustomer) {


                $dbCustomer->address()->updateOrCreate(['type' => 'address', 'customer' => $dbCustomer->id], [
                    'address' =>  $data['Other_Street'] ?? '',
                    'city' => $data['Other_City'] ?? '',
                    'state' => $data['Other_State'] ?? '',
                    'postalCode' => $data['Other_Zip'] ?? '',
                    'country' => $data['Other_Country'] ?? '',
                    'type' => 'address'
                ]);

                //save billing address
                $dbCustomer->billingAddress()->updateOrCreate(['type' => 'billing', 'customer' => $dbCustomer->id], [
                    'address' =>  $data['Mailing_Street'] ?? '',
                    'city' => $data['Mailing_City'] ?? '',
                    'state' => $data['Mailing_State'] ?? '',
                    'postalCode' => $data['Mailing_Zip'] ?? '',
                    'country' => $data['Mailing_Country'] ?? '',
                    'type' => 'billing'
                ]);

                //ExportLeadsToSimPro::dispatch($dbCustomer);

                if (($dbCustomer->wasRecentlyCreated) || ($dbCustomer->wasChanged())) {
                    Log::debug(sprintf('%s:%s %s email:%s , type=%s created/updated from zoho customer id: %d ', __CLASS__, __LINE__, $dbCustomer->customer_type, $dbCustomer->email, $dbCustomer->is_company ? 'Company' : 'Individual',  $customerId));

                    ExportCustomerToSimPro::dispatch($dbCustomer);
                } else if (!$dbCustomer->sim_id) {
                    Log::debug(sprintf('%s:%s email:%s simpro id not found. zoho customer id: %d ', __CLASS__, __LINE__, $dbCustomer->email, $customerId));
                    //ExportLeadsToSimPro::dispatch($dbCustomer);
                    /* Bus::chain([new  ExportCustomerToSimPro($dbCustomer), new ExportCustomersToZoho($dbCustomer)])->dispatch(); */
                    ExportCustomerToSimPro::dispatch($dbCustomer);
                } else {
                    Log::debug('No change in the customer information: ' . $dbCustomer->email);
                }

                if ($data['SimPro_ID'] == '') {
                    ExportCustomersToZoho::dispatch($dbCustomer);
                }
            } //if $dbCustomer ends
            else {
                Log::emergency(__CLASS__ . __LINE__ . 'Customer not created / saved in db: Zoho customer Id: ' . $customerId);
            }
        } catch (ZCRMException $ex) {

            Log::error(__CLASS__ . ':' . __LINE__ . ': ' . $ex->getMessage());
        } catch (Exception $ex) {
            Log::error(__CLASS__ . ':' . __LINE__ . ': ' . $ex->getMessage());
        }
    }
}
